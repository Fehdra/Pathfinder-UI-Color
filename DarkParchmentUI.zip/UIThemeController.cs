// DarkParchmentUI/UIThemeController.cs

using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DarkParchmentUI
{
    internal static class UIThemeController
    {
        private static bool _enabled;
        private static int _applySeq;

        public static void Enable()
        {
            if (_enabled) return;
            _enabled = true;

            Runner.Ensure();
            SceneManager.sceneLoaded += OnSceneLoaded;

            // Initial apply (enable mid-session or first load)
            _applySeq++;
            Runner.Instance.Run(DelayedApply(_applySeq));
        }

        public static void Disable()
        {
            if (!_enabled) return;
            _enabled = false;

            SceneManager.sceneLoaded -= OnSceneLoaded;

            _applySeq++;

            ThemeApplier.RestoreAll();
            ThemeApplier.ClearAllTracking();

            Runner.DestroyRunner();
        }

        private static void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (!_enabled) return;

            // UI often rebuilds after scene load
            _applySeq++;
            Runner.Instance.Run(DelayedApply(_applySeq));
        }

        private static IEnumerator DelayedApply(int seq)
        {
            // Goal: avoid huge FPS drops during the game’s UI/layout “storm”.
            // We do ONE scan per scene and spread work across frames.

            // Let Unity build initial UI/layout first.
            yield return null;
            yield return null;

            if (!_enabled || seq != _applySeq) yield break;

            Canvas[] canvases = null;

            // No yield inside try/catch: fetch canvases safely
            if (!SafeRun(() => { canvases = Object.FindObjectsOfType<Canvas>(true); }))
                yield break;

            if (canvases == null) yield break;

            // Apply per-canvas and yield between some canvases
            for (int i = 0; i < canvases.Length; i++)
            {
                if (!_enabled || seq != _applySeq) yield break;

                var c = canvases[i];
                if (c == null) continue;

                // Apply to this canvas safely
                SafeRun(() => ThemeApplier.ApplyToRoot(c.gameObject));

                // Spread the cost across frames
                if ((i & 1) == 1)
                    yield return null;
            }

            // Run HUD hiding once
            SafeRun(() => ThemeApplier.ApplyHudVisibilityNow());

            // Text tint is expensive, so delay and do once
            var s = Main.Settings;
            if (s != null && s.EnableTextTint)
            {
                yield return new WaitForSeconds(0.75f);

                if (!_enabled || seq != _applySeq) yield break;

                SafeRun(() => ThemeApplier.ApplyTextToAll());
            }
        }

        private static bool SafeRun(System.Action action)
        {
            try
            {
                action?.Invoke();
                return true;
            }
            catch (System.Exception e)
            {
                // Never let a bad UI element kill the whole apply loop
                Main.Logger.Error(e);
                return false;
            }
        }
    }
}
